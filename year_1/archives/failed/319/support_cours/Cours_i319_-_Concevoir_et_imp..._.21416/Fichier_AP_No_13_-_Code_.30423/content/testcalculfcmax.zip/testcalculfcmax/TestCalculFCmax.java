package testcalculfcmax;

public class TestCalculFCmax {


    public static void main(String[] args) {
        
        Fenetre maFenetre = new Fenetre();
    }
    
}
