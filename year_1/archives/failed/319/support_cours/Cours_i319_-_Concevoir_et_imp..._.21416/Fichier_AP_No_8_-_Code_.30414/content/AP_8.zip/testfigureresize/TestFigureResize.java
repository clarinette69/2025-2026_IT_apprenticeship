package testfigureresize;

public class TestFigureResize {

    public static void main(String[] args) {
        
        // Instanciation classe Fenetre
        Fenetre MaFenetre = new Fenetre();
    }
    
}
