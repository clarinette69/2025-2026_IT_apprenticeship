package testfigureresize;

import java.awt.Dimension;
import javax.swing.JFrame;

public class Fenetre extends JFrame {
    public Fenetre(){
        
        super();
        
        // Titre de la fenêtre
        this.setTitle("Une fenêtre dynamique");
        
        // Taille de la fenêtre
        this.setSize(600, 600);
        
        // Taille minimale de la fenêtre
        this.setMinimumSize(new Dimension(400,400));
                
        // Position par défaut (plein centre)
        this.setLocationRelativeTo(null);
        
        // Libération mémoire à la fermeture
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        //Instancier un Panneau et le coller sur le contentPane
        this.setContentPane(new Panneau());
                
        // Rendre visible la fenêtre
        this.setVisible(true);
    }
}