package testfigureresize;

import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel;

public class Panneau extends JPanel {
    public Panneau(){
        super();
    }
    
    public void paintComponent(Graphics g){
        
        // Calculer centre fenêtre (taille du panneau)
        int x = this.getWidth()/4;
        int y = this.getHeight()/4;
        
        // Dessiner un carré noir bords ronds
        g.setColor(Color.black);
        g.fillRoundRect(x-40, y-40, 80+this.getWidth()/2, 80+this.getHeight()/2, 40, 40);
        
        // Dessiner le carré bleu plein (inscrit)
        g.setColor(Color.blue);
        g.fillRect(x-20, y-20, 40+this.getWidth()/2, 40+this.getHeight()/2);
        
        // Dessiner l'ovale rouge plein (inscrit)
        g.setColor(Color.red);
        g.fillOval(x, y, this.getWidth()/2, this.getHeight()/2);
        
    }
}
