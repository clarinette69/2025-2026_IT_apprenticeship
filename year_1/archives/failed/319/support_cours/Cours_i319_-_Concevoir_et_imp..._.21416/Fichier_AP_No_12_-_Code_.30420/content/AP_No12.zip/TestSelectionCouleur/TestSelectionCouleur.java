package testselectioncouleur;

public class TestSelectionCouleur {

    public static void main(String[] args) {
        
// Instanciation d'une Fenetre
        Fenetre maFenetreDeTest = new Fenetre();
    }
    
}
