package testselectioncouleur;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

        
public class Fenetre extends JFrame{

    private JPanel main = new JPanel();
    private JPanel north = new JPanel();
    private JPanel south = new JPanel();   
    private JPanel center = new JPanel();
    private JLabel label = new JLabel();
    private Font font = new Font("verdana", Font.BOLD, 30);
    
    public Fenetre(){
		super();
        this.setTitle("Application pratique No 11");
        this.setSize(400, 400);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        
        // Grille panneau MAIN
        main.setLayout(new BorderLayout());
        
        // Boutons du panneau NORD
            // Grille
            north.setLayout(new GridLayout(2,2));
            JButton b1 = new JButton("ROUGE");
            north.add(b1);
            b1.addActionListener(new Bouton1Listener());
            JButton b2 = new JButton("VERT");
            north.add(b2);
            b2.addActionListener(new Bouton2Listener());
            JButton b3 = new JButton("BLEU");
            north.add(b3);
            b3.addActionListener(new Bouton3Listener());
            JButton b4 = new JButton("JAUNE");
            north.add(b4);
            b4.addActionListener(new Bouton4Listener());
        
        // Bouton panneau SUD
            //Grille
            south.setLayout(new GridLayout(1,1));
            JButton b5 = new JButton("RESET");
            south.add(b5);
            b5.addActionListener(new Bouton5Listener());
        
        // Panneau d'affichage CENTEE
        center.setBackground(Color.white);
        center.add(label);
        
        // Ajout des composants
        
        main.add(center, BorderLayout.CENTER);
        main.add(south, BorderLayout.SOUTH);
        main.add(north, BorderLayout.NORTH);
        
        this.setContentPane(main);
        this.setVisible(true);
    }
    

    class Bouton1Listener implements ActionListener{
    
        public void actionPerformed(ActionEvent arg0){
            label.setFont(font);
            label.setForeground(Color.black);
            label.setText("ROUGE");
            center.setBackground(Color.red);
        }
    }

    class Bouton2Listener implements ActionListener{
    
        public void actionPerformed(ActionEvent arg0){
            label.setFont(font);
            label.setForeground(Color.black);
            label.setText("VERT");
            center.setBackground(Color.green);
        }
    }

    class Bouton3Listener implements ActionListener{
    
        public void actionPerformed(ActionEvent arg0){
            label.setFont(font);
            label.setForeground(Color.white);
            label.setText("BLEU");
            center.setBackground(Color.blue);
        }
    }

    class Bouton4Listener implements ActionListener{
    
        public void actionPerformed(ActionEvent arg0){
            label.setFont(font);
            label.setForeground(Color.black);
            label.setText("JAUNE");
            center.setBackground(Color.yellow);
        }
    }

    class Bouton5Listener implements ActionListener{
    
        public void actionPerformed(ActionEvent arg0){
            label.setText("");
            center.setBackground(Color.white);
        }
    }
}