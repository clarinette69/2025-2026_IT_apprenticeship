package testdessin;

// (C) Tony Favre-Bulle - 2022

import java.awt.*;
import javax.swing.*;

public class Panneau extends JPanel{
    // Attributs
    
    // Méthodes
        // Constructeur
        public Panneau(){
            super();
        }
        
    public void paintComponent (Graphics obGraph){
        // Identificateurs
        int panW, panH = 0;         // Largeur et hauteur du panneau
        int rayon = 0;              // Rayon du cercle circonscrit
        int centreX, centreY = 0;   // Centre panneau
        int coordX, coordY = 0;     // Coordonnées origine dessin
        final int points = 3;       // Trois points (triangle)
        int x[] = new int[points];  // Coordonnées X des points du triangle
        int y[] = new int[points];  // Coordonnées Y des points du triangle
        
        // Epaisseur du trait
        Graphics2D g = (Graphics2D) obGraph;
        BasicStroke line = new BasicStroke(4.0f);
        g.setStroke(line);
        
        // Taille panneau (dynamique)
        panW = this.getWidth();
        panH = this.getHeight();
        
        // Calcul rayon cercle circonscrit
        if (panW <= panH){
            // Largeur panneau déterminante
            rayon = 3*panW/4;
        }else{
            // Hauteur panneau déterminante
            rayon = 3*panH/4;
        }
        
        // Centre du panneau
        centreX = panW/2;
        centreY = panH/2;
        
        // Dessin cercle circonscrit
        coordX = centreX-rayon/2;
        coordY = centreY-rayon/2;
        obGraph.setColor(Color.red);
        obGraph.drawOval(coordX, coordY, rayon, rayon);
        
        // Dessin forme(s) inscrite(s)
        obGraph.setColor(Color.blue);
        obGraph.translate(coordX+rayon/2, coordY+rayon/2);
        
        // Dessin triangle (pointe en bas)
        for (int i=0; i<points; i++)
        {
            y[i] = (int) (rayon/2*Math.cos(i*2*Math.PI/points));
            x[i] = (int) (rayon/2*Math.sin(i*2*Math.PI/points));
        }
        obGraph.fillPolygon(x, y, points);
    }
}
