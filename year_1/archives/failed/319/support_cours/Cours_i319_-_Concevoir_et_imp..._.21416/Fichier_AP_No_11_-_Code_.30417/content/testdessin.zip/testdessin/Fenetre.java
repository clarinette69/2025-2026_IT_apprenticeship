package testdessin;

// (C) Tony Favre-Bulle - 2022

import java.awt.*;
import javax.swing.*;

public class Fenetre extends JFrame{
    // Attributs
    Panneau monPanneau = new Panneau();
    // Méthodes
        // Constructeur
        public Fenetre(){
            super();
            
            this.setTitle("Dessin dynamique");
            this.setSize(500, 500);
            this.setMinimumSize(new Dimension (400,400));
            this.setLocationRelativeTo(null);
            this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            
            // Panneau
            this.setContentPane(monPanneau);
            
            this.setVisible(true);            
        }
}
