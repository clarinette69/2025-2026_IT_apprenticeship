package testdessin;

// (C) Tony Favre-Bulle - 2022

public class TestDessin {

    public static void main(String[] args) {
        // Instanciation de la classe Fenetre
        Fenetre maFenetre = new Fenetre();
    }

}