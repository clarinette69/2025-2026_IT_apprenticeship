package NomCandidat;

// (C) Tony Favre-Bulle - Mai 2024
// EPSIC - Ecole professionnelle Lausanne

public class CDC_2024 {

    public static void main(String[] args) {
        // Instenciation de la classe Fenetre      
        Fenetre maFenetre = new Fenetre();
    }

}
