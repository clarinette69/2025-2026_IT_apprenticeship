package NomCandidat;

// (C) Tony Favre-Bulle - Mai 2024
// EPSIC - Ecole professionnelle Lausanne

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Fenetre extends JFrame{
    private JPanel main = new JPanel();
    private JPanel north = new JPanel();
    private JTextField octet1 = new JTextField();
    private JTextField octet2 = new JTextField();
    private JTextField octet3 = new JTextField();
    private JTextField octet4 = new JTextField();
    private JPanel center = new JPanel();
    private JLabel classText = new JLabel("Veuillez saisir une adresse IP");
    private JPanel south = new JPanel();
    private JButton validate = new JButton("VALIDER");
    private JButton reset = new JButton("RESET");
    
    public Fenetre(){
        this.setTitle("Classes IP [ RFC-950 ] - CDC 2024");
        this.setSize(500, 200);
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            // Main
            main.setLayout(new BorderLayout());
            
            // North - Saisie IP
            north.add(octet1);
            north.add(octet2);            
            north.add(octet3);            
            north.add(octet4);
            main.add(north, BorderLayout.NORTH);
            
            // Center - Affichage classe
            
            
            main.add(center, BorderLayout.CENTER);
            
            // South - Boutons d'action
            
            south.add(validate);
                // Action
                validate.addActionListener(new validateListener());
				
            
            south.add(reset);
                // Action
                reset.addActionListener(new resetListener());
				
            main.add(south, BorderLayout.SOUTH);
        
        this.setContentPane(main);
        this.setVisible(true);
    }
    
    // Classes écouteurs d'événements
    class validateListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent evt){
            
            
        }
    }
    
    class resetListener implements ActionListener{
        @Override
        public void actionPerformed(ActionEvent evt){
            // Effacer les champs IP
            octet1.setText("");
            octet2.setText("");
            octet3.setText("");
            octet4.setText("");
            
            // Efface texte classe
            classText.setText("Veuillez saisir une adresse IP");
        }
    }

}
