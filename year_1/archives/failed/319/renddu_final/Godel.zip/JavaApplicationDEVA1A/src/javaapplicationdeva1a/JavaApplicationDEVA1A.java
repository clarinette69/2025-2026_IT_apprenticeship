/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplicationdeva1a;

/**
 *
 * @author logod
 */
public class JavaApplicationDEVA1A {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char tableau [] = {'a','b','c','d','e','f','g'};
        for(int index = 0; index < tableau.length; index++)
        {
        System.out.println( "A l’index No " +
        index +" du tableau est mémorisé " +
        tableau[index] );
        }
    }
    
}
